import java.io.File; 
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;



//Emily ENg
//client for country data project
//will read from from file and analyze the data 
//October 6, 2022




//Country country1 = new Country (name , series, Years, data);

public class CountryDataClient {
	
	public static void main(String[] args) throws FileNotFoundException {

		//double[] values = new double []{};
		
			
		File inputFile = new File ("CountryData.csv");
		Scanner input = new Scanner (inputFile);
		
		String series = input.nextLine();
		
		String[] splitline1 = series.split(","); 							//split lines are the numbers
		series = splitline1[0];												//series 		
		
		//System.out.println( '\u0022' + series + '\u0022' );			<---- prints old series
		
		String[] years = input.nextLine().split(",");						//gets years here
		String pINTTHIS = "";
		int[] cheese = new int [years.length];
		for(int i = 1; i < years.length;i++) {								//prints years
		cheese[i] = Integer.parseInt(years[i]);
		
			}
		//int[] Years = cheese;
		ArrayList<Integer> Years = new ArrayList <Integer> ();										
		for(int i: cheese) {
			Years.add(i);
		}	
		
		ArrayList <Country> everything = new ArrayList <Country> ();
		
		
		while(input.hasNextLine()==true){									//here the loop
		
//		System.out.println("");
		splitline1 = input.nextLine().split(",");
	 
		if(splitline1.length > years.length) {
			String [] temp = new String [splitline1.length-1];					//THING THAT DOES THING
			String welp =  (splitline1[0] + splitline1[1]);
			String [] christ = welp.substring(1,welp.length()-1).split(" ");
			welp = (christ[1] + " " + christ[0]);
			temp[0] = welp;																//until about here
			
			for(int i = 1; i < splitline1.length-1; i++) {
				temp[i] = splitline1[i+1];
			}
			String [] anothertemp = splitline1[0].split("\"\"");
			welp = Arrays.toString(anothertemp);
			splitline1 = temp;
		}

		String [] splitline = splitline1;					
		String country = splitline1[0];
		String name = country;

//		for(int i = 1; i < splitline.length;i++) {
//			splitline[i] = Double.toString(round(Double.parseDouble(splitline[i])));
//			System.out.print(splitline[i] + "\t\t");													//prints numbers
//		}
		
		String numb = "";																	// the numbers because why not, contain all numbs

		double[] numbers = new double [splitline.length-1];		
		
																							// numbers array 
		for(int i = 1; i < splitline.length;i++) {
			numbers[i-1] = (round(Double.parseDouble(splitline[i])));
			numb += (round(Double.parseDouble(splitline[i]))) + "\t\t";
		}
		ArrayList <Double> data = new ArrayList <Double> ();

		for(double p: numbers) {
			data.add(p);
		}

		Country country1 = new Country (name , series, Years, data);
				
		everything.add(country1);
		
		// print with too String method
		//System.out.println(country1.toString());
		
		}
		
		for(Country p: everything) {
			System.out.println(p);
		}
		}
	

	//rounding method 
		public static double round(double p) {
			p = (Math.round(p*100.00))/100.00;
			return p ;
		}
				
		public static void removeByName(ArrayList<Country> countries, String name) {
			int num = 0;
			//finds name here
			for(int i = 0; i < countries.size(); i++) {
				//removes if find
				if(countries.get(i).equals(name)) {
					num = i;
					countries.remove(i);
				}
			}
			countries.remove(num);
		}
		//this works somehow
		public static void removeNoTrend(ArrayList<Country> countries) {
	    	ArrayList <Integer> things = new ArrayList <Integer>();

	    	//finds the no trends
			for(int i = 0; i < countries.size(); i++) {
		    	Country thing = countries.get(i);
		    		if(thing.getTrend() == ("no trend")) {
		    			things.add(i);
		    		}
		    	}
			//removes the ones with no trend based on counter, from things(array list of numbered places to remove)
		    	int counter = 0;
	    		for(int i: things) {
	    			countries.remove(i-counter);
	    			counter++;
	    		}
		}
			
		public static ArrayList<String> getListBasedOnTrend(ArrayList<Country> countries, String trendType){ 
			ArrayList <Integer> things = new ArrayList <Integer>();
			ArrayList <String> heh = new ArrayList <String>();
			
			//checks input for up down or no, if not throws exception
			if(trendType.contains("up") || trendType.contains("down") || trendType.contains("no trend")){
			}
			else {
			throw new IllegalArgumentException("up,down,no trend");
			}
			
			//find the ones with the inputed trend type
			for(int i = 0; i < countries.size(); i++) {
		    	Country bigword = countries.get(i);
		    		if(bigword.getTrend() == (trendType)) {
		    			things.add(i);
		    			}
		    	}
			
			//gets the name of country with the trend type
			for(int i: things) {
		    	Country another = countries.get(i);
				String p = another.getCountry();
				heh.add(p);
				}
					return heh;
		}
}
