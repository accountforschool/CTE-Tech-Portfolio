import java.util.ArrayList;

//Emily Eng
//December 11, 2022
//countey data checkpoint 4
// Country class will contain all of the info about a country: it's name, series name, years and data for the series 
// It will also be able to calculate and return information about the country




//Country country1 = new Country (name , series, Years, data);

public class Country{
	private String name;
	private String series;
	private ArrayList<Integer> years;
	private ArrayList<Double> values;
	

     //constructor
	public Country(String name, String series, ArrayList<Integer> years, ArrayList<Double> values) {
		this.name = name;
			String [] thing = new String [] {};
			thing = series.split("\\(");
			series = thing[0];
		this.series = series;
		this.years = years;
		this.values = values; 
	}


	public String getUnits() {
		String units = "";
		String temp = "";
		String [] letters = new String [] {};
		//ArrayList <String> arraylist = new ArrayList <String> ();

		letters = series.split("\\(");
		for(int i = 1; i < letters.length; i+=2) {
			temp+= letters[i];
		}
		letters = temp.split("\\)");
		for(int i = 0; i < letters.length; i+=2) {
			units += letters[i];
		}
		
		return units;
	}


	public String getAcronym() {
		String acronym = "";
		String temp = "";
		String [] letters = new String [] {};
		letters = series.split("\\(");
		temp = letters[0];
		for (String s : temp.split(" ")) { 
			if(s.length() > 2) {
				acronym+=s.charAt(0);
				acronym= acronym.toUpperCase();
			}
		}		
		return acronym;
	}


	public double min() {
		double min = values.get(0);
		for (int i=1; i<values.size();i++) {
			double data = values.get(i);
			if (data< min) 
				min = data;
		}
		return min;
	}

	public double max() {
		double max = values.get(0);
		for (int i=1; i<values.size();i++) {
			double data = values.get(i);
			if (data> max) 
				max = data;
		}
		return max;
	}

	public String getTrend() {
		String trend = "no trend";
		if(trendsUp() == true) {
			trend = "up"; 
		}
		if(trendsDown() == true) {
			trend = "down";
		}
		return trend; 
	}

	private boolean trendsUp() {
	    for (int i = 1; i < values.size(); i++) {
	        Boolean incremental = values.get(i - 1) < values.get(i);
	        if (!incremental) return false;
	    }
	    return true;
	}

	private boolean trendsDown() {
		 for (int i = 1; i < values.size(); i++) {
		        Boolean incremental = values.get(i - 1) > values.get(i);
		        if (!incremental) return false;
		    }
		    return true;
		}
	
	//prints out whole thing
	public String toString() {			
		String output="";
		for (int i=1; i < years.size();i++) {
			output +=years.get(i)+"\t";
		}
		output +="\n";
		for (int i=0; i < values.size();i++) {
			double value =Math.round(values.get(i)*100.0)/100.0;
			output +=value+"\t";
		}
		output +="\nThis is the \""+series+"\" for "+ name +"\n";
		output +="Minimum: " + min() + "\n" + "Maximum: " + max();
		output+="\n";
		output+= "Trending:" + getTrend() + "\n";
		return output;
	}

	public void addDataPoint(int year, double newDatum) {
		years.add(year);
		values.add(newDatum);
	}
	
	public void editDataPoint(int year, double newDatum) {
		int num = 0;
		for(int i = 0; i < years.size(); i++) {
			if(years.get(i)==year) {
				num = i;
			}
		}
		values.set(num, newDatum);
	}

	
	public String getCountry() {
		return name;
	}
	public String getSeries() {
		return series;
	}
	public ArrayList<Integer> getYears() {
		return years;
	}
	public ArrayList<Double> getData() {
		return values;
	}
	public void setSeries(String s) {
		series = s;
	}
	public void setData(ArrayList<Double> d) {
		values=d;
	}
}
