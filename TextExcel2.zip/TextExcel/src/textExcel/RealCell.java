package textExcel;


//Emily Eng
//5/12/2023
//RealCell, the cells that hold numbers and participate in calculations, returns abreviated text , the full text, and the value as a double

public class RealCell implements Cell {
	

	private String values = ""; 
	
	public RealCell(String value) { 
		this.values=value;
	} 
	
	public String abbreviatedCellText() { 
		String returnthis = (Double.parseDouble(values) + "          ");
		
		return returnthis.substring(0,10);
	}
 
	public String fullCellText() { 
		return (values); 
	} 
	public Double getDoubleValue(){
		Double d = Double.parseDouble(values);
		return d;   
	}
}    
  
