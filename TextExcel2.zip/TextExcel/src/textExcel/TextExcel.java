//
package textExcel;

import java.io.FileNotFoundException;
import java.util.Scanner;

//Emily Eng
//5/12/2023
//TextExcel, maian method, takes in command, and prints out updated spreadsheet, stop when quit command entered

public class TextExcel
{ 

	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		boolean run = true;
		String quit = "QUIT"; 
		 Spreadsheet spreadsheet = new Spreadsheet();
		System.out.println(spreadsheet.getGridText());
		while (run){
		    String input = scanner.nextLine();
		   	System.out.println(spreadsheet.processCommand(input));
			    
		if (quit.equals(input.toUpperCase()))
			run = false; 
		}
		scanner.close();
	} 
} 
 


 


 




