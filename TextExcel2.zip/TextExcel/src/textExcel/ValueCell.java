package textExcel;

//Emily Eng
//5/12/2023
//ValueCell, does real cell things

public class ValueCell extends RealCell{
	private String value; 
	
	public ValueCell(String value) {
		super(value);
		this.value = value;
		// TODO Auto-generated constructor stub
		
	}
}
