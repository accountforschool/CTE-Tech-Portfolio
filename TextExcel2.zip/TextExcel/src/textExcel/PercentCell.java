package textExcel;


//Emily Eng
//5/12/2023
//PercentCell, takes decemial percent, returns abrreviated number as a percent with % sign 

public class PercentCell extends RealCell {
	private String value;
	
	public PercentCell(String value) {
		super(value); 
		this.value = value;
	} 
	
	public String abbreviatedCellText() {
		
		String abbreviated = Double.toString(Double.parseDouble(value)*100).split("\\.")[0] + "%           ";
		return abbreviated.substring(0,10);
	}

}    