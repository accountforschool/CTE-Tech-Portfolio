package textExcel;

//Emily Eng
//5/12/2023
//Emptycell, cell with nothing, preset for cells 

public class EmptyCell implements Cell {

	public EmptyCell() {
		 
	}
	public String abbreviatedCellText() {
		// TODO Auto-generated method stub
		return "          ";
	}

	@Override
	public String fullCellText() {
		// TODO Auto-generated method stub
		return "";  
	}    


}
