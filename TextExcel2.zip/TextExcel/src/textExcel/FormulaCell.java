package textExcel;

//Emily Eng
//5/12/2023
//Formula Cell
//when the assignment command specifies an expression contained in parentheses
//When the user inspects a FormulaCell , prints the complete formula, including the outer parentheses
//When the full spreadsheet prints, the formula will be evaluated, and the final value printed in the spreadsheet

public class FormulaCell extends RealCell{
	private String value;
	private Spreadsheet spread; 
	
	public FormulaCell(String value,Spreadsheet spread) {									//value is input no math, spreadsheet to use the getCell 
		super(value);
		this.value = value;
		this.spread = spread; 
		// TODO Auto-generated constructor stub
	}

	//does the math - splits by spaces then takes maath operator and does approprate math operation 
 	
	public Double getDoubleValue() {															// DOUBLE VALUE
		 //G8 = ( sum A1-E4 ) , value -> sum A1-E4
		Double results = 0.0;  
		String value2 = value.toLowerCase();  
		String[] formula = value2.split(" ");													//makes input lowercase and splits it by spaces
		String s = formula[0].toLowerCase(); 
	 	
		
		//SUM AND AVG STUFFS
		if(s.contains("sum") || s.contains("avg")) {											// sum + averages 
			SpreadsheetLocation first = new SpreadsheetLocation(formula[1].split("-")[0]);
			SpreadsheetLocation second = new SpreadsheetLocation(formula[1].split("-")[1]);		//new spreadsheet locations 
			
			//gets the values of each cell + adds them
			int counter = 0;
			 
			for(int i = first.getRow(); i <= second.getRow();i++) {								//gets value at row and increments until  
				for(int p = first.getCol(); p <= second.getCol();p++) {							//same row as the other then same for colums 
					  
					char precol = (char) (p + 65);
					String col = String.valueOf(precol);  										//get row and col number 
					int row = i+1;  
					  
					String loc001 = col+row;
					SpreadsheetLocation loc = new SpreadsheetLocation((loc001)); 
					  
					
					if( !spread.getCell(loc).getClass().equals(EmptyCell.class)){ 				//if the cell is not emptycell, get doubleValue and add to results 
						results += ((RealCell) spread.getCell(loc)).getDoubleValue();;
					} 
 
					counter++;  
				}    
			}
			//divides for avg 	
			if(s.contains("avg")) {																//if for averages it divides by num of cells it looked at 
				results= (results/counter);
			} 
		}
		 
	//MATHS 																	//MATHS  
		else { 
		for(int i = 0; i< formula.length; i++) {
			String p = formula[i];												//goes through all index in array, if is cell loc, it gets value at that cell
			if(Character.isLetter(p.charAt(0))){								// and replaces the array index with the value of the cell 
				SpreadsheetLocation loc = new SpreadsheetLocation(p); 
				RealCell cell = (RealCell)spread.getCell(loc);
				  
				formula[i]=cell.getDoubleValue().toString(); 
 
			}  
		}
		
		results = Double.parseDouble(formula[0]);								//results is set to value of first num, then get two values, the math sign, and the
		for(int i = 0; i < formula.length-1; i+=2) {							// number after it, does correct operation depending on math sign, and repeats until end 
			 Double num = Double.parseDouble(formula[i+2]);
			 String sign = formula[i+1];
				 
				 if(sign.equals("+")) {
					 results += num;
				 } 
				 else if(sign.equals("-")) {
					 results -= num;
				 }
				 else if(sign.equals("/")) { 
					 results/= num; 
				 }
				 else if(sign.equals("*")) { 
					 results*=num;
				 } 	 
			}  
		}
		return results;
	} 
	
	public String fullCellText() {											//return original input before math done with parentwesies 
			return "( " + value + " )";
	 }
	 
	 public String abbreviatedCellText() {		 	
			String abbreviated =  getDoubleValue() + "            ";		//does the math shortens to 10 nums and return it
			return abbreviated.substring(0,10);
	 }

}
  