package textExcel;

//Emily Eng
//5/12/2023
//SpreadsheetLocation, takes the name of a cell and gives you the row and column number 

public class SpreadsheetLocation implements Location{
	private int column;
	private int row;

	
    @Override
    public int getRow() 												//return the row number
    {
        // TODO Auto-generated method stub
        return row; 
    }

    @Override 
    public int getCol()													//return the col numnber
    {
        // TODO Auto-generated method stub
        return column;  
    } 
     
    public SpreadsheetLocation(String cellName){						//gives you row number and colum number from cell location 
    	
    	char letter = Character.toUpperCase(cellName.charAt(0));
    	int c = (char)letter;
    	column = c-65; 
    	
    	row = Integer.parseInt(cellName.substring(1))-1;
     	
    }
  
} 
