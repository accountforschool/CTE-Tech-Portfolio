package textExcel;

//Emily Eng
//5/12/2023
//TextCell, Cell that stores strings, returns full string or abbreviated 

public class TextCell implements Cell{
	
	private String values = ""; 
	
	public TextCell(String value) {
		this.values=value;
	}
	public String abbreviatedCellText() {
		String returnthis = (values + "          ");
		return returnthis.substring(0,10);
	}
   
	public String fullCellText() {

		return ("\"" + values + "\"");
	}

}
