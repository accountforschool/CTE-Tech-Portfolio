import java.util.Arrays;


public class Split {

 public static void main(String[] args) {

////ex1
//String[] ex1="I like apples!".split(" ");
//System.out.println(Arrays.toString(ex1));
////ex2
//String[] ex2="I really like really red apples!".split("really");
//System.out.println(Arrays.toString(ex2));
////ex3
//String[] ex2a="I reallyreally likeapples".split("really");
//System.out.println(Arrays.toString(ex2a));


System.out.println(getFilling("abpplespineapplesbreadmayohambreadcheese"));
System.out.println(getFilling("breadmayobread"));
System.out.println(getFilling("applesbreadmayobread"));
System.out.println(getFilling("breadhambreadcheese"));
System.out.println(getFilling("breadbread"));
System.out.println(getFilling("breadcheese"));
System.out.println(getFilling("hamcheesebread"));
System.out.println(getFilling("cheese"));
System.out.println(getFilling("breadcheesebreadhambread"));
System.out.println(getFilling("hambreadmayobaconbreadavocadobread"));


System.out.println(getFilling2(" apples bread mayo bread"));
System.out.println(getFilling2("bread ham bread cheese"));
System.out.println(getFilling2("bread bread"));
System.out.println(getFilling2("bread cheese"));
System.out.println(getFilling2("ham bread mayo bacon bread avocado bread"));
 }

public static String getFilling(String sandwitch)
{
String[] p1=new String [] {};
String myStr=new String() ;


if(sandwitch.contains("bread"))
{
    int iBegin = sandwitch.indexOf("bread")+5;
    int iEnd   = sandwitch.lastIndexOf("bread");
   
    if (iBegin > 1 && iEnd >5 &&  iBegin < iEnd)
    {
   
        myStr = sandwitch.substring(iBegin,iEnd);
       
        p1=myStr.split("bread");
    }
}
return Arrays.toString(p1);
}


public static String getFilling2(String sandwitch) {
//p2
String p2= sandwitch;
return (getFilling(p2));
}
}
